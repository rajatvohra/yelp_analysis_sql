import React from "react";

export const CreateAccount = () => {
  return <span>Create Account</span>;
};
